import './App.css'
import Footer from './component/Footer.jsx'
import Header from './component/Header.jsx'
import Home from './page/Home.jsx'
import {BrowserRouter, Routes, Route} from 'react-router'

function App() {
  
  return (
    
    <>
      <BrowserRouter>
          <Header/>
          <Routes>
            <Route path='/' element={<Home/>}></Route>
          </Routes>
          <Footer/>
      </BrowserRouter>
    </>
      
  
  )
}

export default App
