const mongoose = require('mongoose')

const connectionDatabase = () => {
    mongoose.connect(process.env.DB_URL).then((con) => {
        console.log(con.connection.host);
    }).catch((err) => { console.error('Error connecting to MongoDB:', err); });
} 

module.exports = connectionDatabase;