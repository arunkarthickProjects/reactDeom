import React from 'react'
import ProductCard from '../component/ProductCart.jsx'
import { useState } from 'react'
import { useEffect } from 'react'





const Home = () => {

  const[Products,setProducts] = useState([])

  useEffect(() => {
    const apiUrl = import.meta.env.VITE_API_URL; 

     console.log(apiUrl);
    // fetch(`${apiUrl}/product`).then(res => res.json()).then(res => setProducts(res.products))
   
    const fetchProducts = async() => {
       try {
         const response = await fetch(`${import.meta.env.VITE_API_URL}/product`);
         console.log('Fetching from URL:', `${import.meta.env.VITE_API_URL}/product`); 
        if(!response.ok){
         throw new Error ('Network response was not okay')
        }
        const data =await response.json()
        setProducts(data.products)
        
       } catch (error) {
        console.log('Error fetching products:', error);
       }
    };

    fetchProducts();

  },[])

  return (
    <>
      <h1 id="products_heading">Latest Products</h1>
      <section id="products" className="container mt-5">
        <div className="row">
          
          {Products.map((product) => < ProductCard key={product._id} product={product}/>)}
         
        </div>
      </section>
    </>
  )
}

export default Home