// req handler
const orderModel = require('../models/orderModule')

exports.createOrder = async (req, res, next) => {

    const cartItems = req.body;
    const amount = cartItems.reduce((acc ,items) => Number(acc + items.product.price * items.qty),0).toFixed(2)
    const status = "pending"

   const orderProduct = await orderModel({cartItems,amount,status})
    res.json({
        success : true,
        orderProduct
    })
}